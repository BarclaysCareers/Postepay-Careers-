import React, { useState } from 'react';
import axios from 'axios';

export default function Register() {
  const [form, setForm] = useState({
    fullname: '',
    email: '',
    password: ''
  });
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setForm({...form, [e.target.name]: e.target.value});
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/api/register', form);
      setMessage('Account created successfully!');
    } catch (err) {
      setMessage('Error: ' + err.response.data.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-blue-50">
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow-md w-96">
        <img src="/assets/barclays-logo.png" alt="Barclays Logo" className="w-24 mx-auto mb-4" />
        <h2 className="text-2xl mb-4 font-semibold text-center">Barclays - Register</h2>
        <input type="text" name="fullname" placeholder="Full Name" onChange={handleChange}
          className="w-full mb-3 p-2 border rounded" required />
        <input type="email" name="email" placeholder="Email" onChange={handleChange}
          className="w-full mb-3 p-2 border rounded" required />
        <input type="password" name="password" placeholder="Password" onChange={handleChange}
          className="w-full mb-4 p-2 border rounded" required />
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded">Create Account</button>
        <p className="mt-3 text-center text-sm text-green-600">{message}</p>
      </form>
    </div>
  );
}
