import React from 'react';
import Register from './pages/Register';

function App() {
  return <Register />;
}

export default App;
